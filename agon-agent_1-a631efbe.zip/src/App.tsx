import { useEffect, useMemo, useState } from 'react'
import { Activity, ArrowDownToLine, AudioLines, BarChart3, Check, ChevronDown, CircleHelp, Clipboard, Clock3, ExternalLink, FileAudio, Headphones, Languages, Mic2, Pause, Play, Search, Settings2, Volume2, Waves, X } from 'lucide-react'
import './App.css'
import './portal-theme.css'

type Sentence = { id: string; group?: string; text: string; lang: 'en' | 'te'; tag: string }
const sentences: Sentence[] = [
  { id: 'E1', lang: 'en', tag: 'Pronunciation', text: 'The antidisestablishmentarianism movement gained considerable momentum during the parliamentary proceedings.' },
  { id: 'E2a', group: 'E2', lang: 'en', tag: 'Noun · conduct', text: "a) The orchestra's conduct during the ceremony was praised by the audience." },
  { id: 'E2b', group: 'E2', lang: 'en', tag: 'Verb · conduct', text: 'b) The researchers will conduct an experiment to evaluate the proposed method.' },
  { id: 'E3', lang: 'en', tag: 'Prosody', text: 'The rhythm of the orchestra changed unexpectedly.' },
  { id: 'E4', lang: 'en', tag: 'Date & time', text: 'The meeting will start at 10:45 AM on 12 November 2026, so andaroo should arrive on time.' },
  { id: 'T1', lang: 'te', tag: 'Pronunciation', text: 'న్యూ రోఫార్మ కోలాజికల్ పరిశోధనలోనూతన ఔషధాల ప్రభావాన్ని విశ్లషేందుకు ఇచ్చారు.' },
  { id: 'T2a', group: 'T2', lang: 'te', tag: 'తాడు · rope', text: 'a) తాడుపై అతని పట్టుచాలా బలంగా ఉంది.' },
  { id: 'T2b', group: 'T2', lang: 'te', tag: 'పట్టు · silk', text: 'b) ఆమె పట్టుచీరను ధరించి వేడుకకు వచ్చ ింది.' },
  { id: 'T3', lang: 'te', tag: 'Word spacing', text: 'పులి అడ విలో నిశ్శబ్ం ద గా నడిచింది.' },
  { id: 'T4', lang: 'te', tag: 'Date & time', text: 'ఈ సమావేశం 2026 నవంబర్ 12వ తేదీ ఉదయం 10:45 గంటలకు ప్రారంభమవుతుంది, సమయానికి సిద్దంగా ఉంచండి.' },
]

function App() {
  const [language, setLanguage] = useState<'en' | 'te'>('en')
  const [query, setQuery] = useState('')
  const [playing, setPlaying] = useState<string | null>(null)
  const [voice, setVoice] = useState('')
  const [rate, setRate] = useState(0.92)
  const [activeTab, setActiveTab] = useState<'sentences' | 'plots' | 'metrics' | 'preparation'>('sentences')
  const [copied, setCopied] = useState(false)
  const [voiceOptions, setVoiceOptions] = useState<SpeechSynthesisVoice[]>([])

  useEffect(() => {
    const refresh = () => setVoiceOptions(window.speechSynthesis?.getVoices() || [])
    refresh()
    window.speechSynthesis?.addEventListener('voiceschanged', refresh)
    return () => window.speechSynthesis?.removeEventListener('voiceschanged', refresh)
  }, [])
  const availableVoices = useMemo(() => voiceOptions.filter(item => item.lang.toLowerCase().startsWith(language)), [voiceOptions, language])
  const shown = sentences.filter(item => item.lang === language && `${item.id} ${item.text} ${item.tag}`.toLowerCase().includes(query.toLowerCase()))
  const cancelSpeech = () => { window.speechSynthesis?.cancel(); setPlaying(null) }

  const speak = (sentence: Sentence) => {
    if (!window.speechSynthesis) return
    if (playing === sentence.id) return cancelSpeech()
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(sentence.text)
    utterance.lang = language === 'en' ? 'en-US' : 'te-IN'
    utterance.rate = rate
    const selected = availableVoices.find(item => item.name === voice) || availableVoices[0]
    if (selected) utterance.voice = selected
    utterance.onend = () => setPlaying(null)
    utterance.onerror = () => setPlaying(null)
    setPlaying(sentence.id)
    window.speechSynthesis.speak(utterance)
  }
  const playAll = () => {
    if (playing === 'all') return cancelSpeech()
    window.speechSynthesis.cancel()
    setPlaying('all')
    const selected = availableVoices.find(item => item.name === voice) || availableVoices[0]
    shown.forEach((sentence, index) => {
      const utterance = new SpeechSynthesisUtterance(sentence.text)
      utterance.lang = language === 'en' ? 'en-US' : 'te-IN'
      utterance.rate = rate
      if (selected) utterance.voice = selected
      if (index === shown.length - 1) { utterance.onend = () => setPlaying(null); utterance.onerror = () => setPlaying(null) }
      window.speechSynthesis.speak(utterance)
    })
  }
  const downloadManifest = () => {
    const data = { project: 'Clearvoice · Speech test suite', generatedAt: new Date().toISOString(), note: 'Sentence text preserved verbatim. Audio playback uses your browser speech engine; this manifest is not trained-model output.', languages: { English: sentences.filter(s => s.lang === 'en'), Telugu: sentences.filter(s => s.lang === 'te') } }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob); const anchor = document.createElement('a')
    anchor.href = url; anchor.download = 'clearvoice-test-sentences.json'; anchor.click(); URL.revokeObjectURL(url)
  }
  const copyText = async () => {
    await navigator.clipboard?.writeText(shown.map(item => `${item.id}\t${item.text}`).join('\n'))
    setCopied(true); window.setTimeout(() => setCopied(false), 1600)
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#top"><span className="brand-mark"><AudioLines size={19}/></span><span>Fast Speech<span className="brand-period"> AI</span><small>RESEARCH LABORATORY</small></span></a>
      <div className="side-label">WORKSPACE</div>
      <button className={`side-item ${activeTab === 'sentences' || activeTab === 'plots' ? 'selected' : ''}`} onClick={() => setActiveTab('sentences')}><span className="side-icon"><Activity size={17}/></span>Evaluation hub<span className="side-count">10</span></button>
      <button className={`side-item ${activeTab === 'metrics' ? 'selected' : ''}`} onClick={() => setActiveTab('metrics')}><span className="side-icon"><BarChart3 size={17}/></span>Results & metrics</button>
      <button className={`side-item ${activeTab === 'preparation' ? 'selected' : ''}`} onClick={() => setActiveTab('preparation')}><span className="side-icon"><FileAudio size={17}/></span>Experiment overview</button>
      <div className="side-label side-label-spaced">PROJECT</div>
      <div className="project-chip"><span className="project-dot"/><div>FastSpeech 2 TTS<small>EN · TE&nbsp; / &nbsp;ASSIGNMENT</small></div><ChevronDown size={14}/></div>
      <div className="sidebar-bottom"><div className="help-card"><span className="help-circle"><CircleHelp size={16}/></span><b>Need a hand?</b><p>Learn how to prepare a clean speech dataset.</p><button onClick={() => setActiveTab('preparation')}>Read the guide <span>↗</span></button></div><div className="profile"><div className="avatar">R</div><div>Researcher<small>Local workspace</small></div><Settings2 size={16}/></div></div>
    </aside>
    <main className="main" id="top">
      <header className="topbar"><div className="crumb">Research <span>/</span> FastSpeech 2 <span>/</span> <b>{activeTab === 'metrics' ? 'Results & metrics' : activeTab === 'preparation' ? 'Experiment overview' : 'Evaluation hub'}</b></div><div className="top-right"><span className="saved-indicator"><span/> Research workspace</span><div className="avatar small-avatar">FS</div></div></header>
      <div className="content">
        <div className="eyebrow"><span className="eyebrow-line"/> AI RESEARCH LABORATORY <span className="release">TEXT-TO-SPEECH · 2026</span></div>
        <div className="heading-row"><div><h1>FastSpeech 2 <span className="heading-accent">Evaluation Portal</span></h1><p className="subtitle">Research, inspect, and compare neural speech synthesis across English and Telugu.</p></div><button className="button button-outline" onClick={downloadManifest}><ArrowDownToLine size={16}/> Export sentences</button></div>
        <section className="summary-grid">
          <div className="summary-card"><div className="summary-label">TEST SENTENCES <span className="summary-icon"><AudioLines size={16}/></span></div><strong>10</strong><div className="summary-foot">5 English <i/> 5 Telugu</div></div>
          <div className="summary-card"><div className="summary-label">ENGLISH CORPUS <span className="summary-icon mint"><Headphones size={16}/></span></div><strong className="corpus-name">Svarah</strong><div className="summary-foot">English speech dataset</div></div>
          <div className="summary-card"><div className="summary-label">TELUGU CORPUS <span className="summary-icon lilac"><Languages size={16}/></span></div><strong className="corpus-name">IndicTTS</strong><div className="summary-foot">Telugu speech dataset</div></div>
          <div className="summary-card status-card"><div className="summary-label">MODEL STATUS <span className="status-pill"><span/> Awaiting run data</span></div><strong className="status-title">Evaluation workspace</strong><div className="summary-foot">Audio & metrics not in attached files</div></div>
        </section>
        <div className="section-tabs"><button className={activeTab === 'sentences' ? 'tab active' : 'tab'} onClick={() => setActiveTab('sentences')}><AudioLines size={14}/> Generated speech</button><button className={activeTab === 'plots' ? 'tab active' : 'tab'} onClick={() => setActiveTab('plots')}><Waves size={14}/> Variance adaptor</button><button className={activeTab === 'metrics' ? 'tab active' : 'tab'} onClick={() => setActiveTab('metrics')}><BarChart3 size={14}/> Results & metrics</button><span className="tab-spacer"/><span className="last-updated"><Clock3 size={14}/> English · Telugu</span></div>
        {activeTab === 'sentences' ? <>
          <section className="controls-panel"><div className="language-switch"><button className={language === 'en' ? 'lang-button active' : 'lang-button'} onClick={() => {setLanguage('en');cancelSpeech()}}><span className="flag">EN</span> English <span className="lang-total">5</span></button><button className={language === 'te' ? 'lang-button active' : 'lang-button'} onClick={() => {setLanguage('te');cancelSpeech()}}><span className="flag te-flag">తె</span> Telugu <span className="lang-total">5</span></button></div><div className="control-tools"><label className="searchbox"><Search size={15}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Find a sentence" aria-label="Find a sentence"/>{query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={14}/></button>}</label><button className="button button-playall" onClick={playAll}>{playing === 'all' ? <Pause size={15}/> : <Play size={15} fill="currentColor"/>}{playing === 'all' ? 'Stop all' : 'Play all'}</button></div></section>
          <div className="voice-strip"><div className="voice-current"><span className="voice-avatar"><Mic2 size={16}/></span><div><span className="voice-caption">PREVIEW VOICE</span><div className="voice-name">{voice || availableVoices[0]?.name || (language === 'en' ? 'System English voice' : 'System Telugu voice')}</div></div></div><div className="voice-options"><label className="voice-select-label">Voice <select value={voice} onChange={e => setVoice(e.target.value)}><option value="">Default {language === 'en' ? 'English' : 'Telugu'} voice</option>{availableVoices.map(item => <option key={item.name} value={item.name}>{item.name} · {item.lang}</option>)}</select></label><div className="rate-control"><span>Speed</span><input type="range" min="0.65" max="1.15" step="0.05" value={rate} onChange={e => setRate(Number(e.target.value))}/><b>{rate.toFixed(2)}×</b></div></div></div>
          <div className="list-heading"><div><span className="list-overline">{language === 'en' ? 'ENGLISH' : 'తెలుగు'} SUITE</span><h2>{language === 'en' ? 'English test sentences' : 'Telugu test sentences'} <span>· {shown.length}</span></h2></div><button className="icon-action" onClick={copyText}>{copied ? <Check size={16}/> : <Clipboard size={16}/>}<span>{copied ? 'Copied' : 'Copy text'}</span></button></div>
          <div className="sentence-list">{shown.map((item, index) => <article key={item.id} className={`sentence-card ${playing === item.id ? 'is-playing' : ''}`}><div className="sentence-index">{String(index + 1).padStart(2, '0')}</div><div className="sentence-main"><div className="sentence-meta"><span className="sentence-id">{item.group || item.id}</span>{item.group && <span className="sub-id">{item.id.endsWith('a') ? 'a' : 'b'}</span>}<span className="meta-divider"/><span className="sentence-tag">{item.tag}</span></div><p className={language === 'te' ? 'sentence-text telugu' : 'sentence-text'}>{item.text}</p></div><button className={`round-play ${playing === item.id ? 'playing' : ''}`} onClick={() => speak(item)} aria-label={`${playing === item.id ? 'Stop' : 'Play'} ${item.id}`}>{playing === item.id ? <Pause size={16} fill="currentColor"/> : <Play size={16} fill="currentColor"/>}</button></article>)}{shown.length === 0 && <div className="empty-state">No sentences match “{query}”. <button onClick={() => setQuery('')}>Clear search</button></div>}</div>
          <div className="preview-note"><Volume2 size={15}/><span>Preview uses your device’s built-in speech synthesis. It is <b>not</b> generated by a trained project model.</span></div>
          <section className="dataset-callout"><div className="callout-icon"><Languages size={19}/></div><div><b>Assignment corpora</b><p>English: Svarah · Telugu: IndicTTS. Audio playback here is a browser voice preview, not FastSpeech 2 model output.</p></div><button onClick={() => setActiveTab('preparation')}>Experiment overview <span>→</span></button></section>
        </> : activeTab === 'plots' ? <VariancePlots/> : activeTab === 'metrics' ? <MetricsViewer/> : <Preparation/>}
        <footer className="footer"><span>Fast Speech AI <b>·</b> Research laboratory</span><span>English · Telugu TTS evaluation <span className="footer-check">✓</span></span></footer>
      </div>
    </main>
  </div>
}

function VariancePlots() {
  const [metric, setMetric] = useState<'Duration' | 'Pitch' | 'Energy'>('Duration')
  const [lang, setLang] = useState<'English' | 'Telugu'>('English')
  const samples = metric === 'Duration' ? [42,48,44,57,50,64,52,70,61,74,68,82,71,89,76,96,80,103,87,112] : metric === 'Pitch' ? [67,74,71,81,76,90,83,97,89,105,94,110,101,118,108,125,116,133,121,140] : [34,40,38,47,43,53,49,60,55,66,60,72,66,79,71,84,77,92,83,98]
  const line = samples.map((v, i) => `${28 + i * 34},${178 - v}`).join(' ')
  return <div className="research-view"><div className="view-intro"><div><span className="list-overline">INTERACTIVE EVALUATION HUB · 01</span><h2>Variance adaptor inspection</h2><p>Explore the duration, pitch, and energy signals that condition FastSpeech 2’s mel-spectrogram prediction.</p></div><span className="data-badge"><span/> Waiting for model outputs</span></div><div className="view-toolbar"><div className="mini-tabs">{(['Duration','Pitch','Energy'] as const).map(item=><button className={metric === item ? 'mini-tab active' : 'mini-tab'} onClick={() => setMetric(item)} key={item}>{item}</button>)}</div><div className="mini-tabs lang-mini">{(['English','Telugu'] as const).map(item=><button className={lang === item ? 'mini-tab active' : 'mini-tab'} onClick={() => setLang(item)} key={item}>{item}</button>)}</div></div><div className="plot-grid"><section className="chart-card wide-chart"><div className="chart-head"><div><span className="list-overline">{lang.toUpperCase()} · TEST ALIGNMENT</span><h3>{metric} prediction by phoneme</h3></div><span className="chart-unit">{metric === 'Duration' ? 'frames' : metric === 'Pitch' ? 'Hz · normalized' : 'log energy'}</span></div><svg className="research-chart" viewBox="0 0 720 220" role="img" aria-label={`${metric} variance adaptor plot`}><defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#4b6bff" stopOpacity=".25"/><stop offset="1" stopColor="#4b6bff" stopOpacity="0"/></linearGradient></defs>{[35,75,115,155,195].map(y=><g key={y}><line x1="28" x2="700" y1={y} y2={y} className="chart-gridline"/><text x="4" y={y+3} className="chart-tick">{Math.round((195-y)*.8)}</text></g>)}<polygon points={`28,195 ${line} 674,195`} fill="url(#areaFill)"/><polyline points={line} fill="none" stroke="#687bff" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round"/>{samples.map((v,i)=><circle key={i} cx={28+i*34} cy={178-v} r="3.5" fill="#78d7ec" stroke="#141b2a" strokeWidth="2"/>)}<text x="30" y="214" className="chart-tick">phoneme 01</text><text x="630" y="214" className="chart-tick">phoneme 20</text></svg><div className="chart-foot"><span><i className="legend-line indigo-line"/>Predicted {metric.toLowerCase()}</span><span><i className="legend-line cyan-line"/>Phoneme samples</span><span className="illustrative-tag">Illustrative preview</span></div></section><div className="plot-side"><div className="plot-info-card"><span className="plot-icon"><Waves size={17}/></span><div><span className="list-overline">SELECTED ADAPTOR</span><b>{metric} predictor</b><p>{metric === 'Duration' ? 'Regulates phoneme timing and speaking rhythm.' : metric === 'Pitch' ? 'Models F0 contour for expressive intonation.' : 'Controls frame-level loudness and emphasis.'}</p></div></div><div className="plot-info-card"><span className="plot-icon cyan-icon"><Activity size={17}/></span><div><span className="list-overline">EVALUATION STATUS</span><b>Awaiting inference artifacts</b><p>Upload predictor outputs and alignments to inspect real sentence-level variance.</p></div></div></div></div><div className="preview-disclaimer"><CircleHelp size={15}/> Plot values are illustrative interface previews, not measured Svarah or IndicTTS experiment results.</div></div>
}

function MetricsViewer() {
  const [lang, setLang] = useState<'English · Svarah' | 'Telugu · IndicTTS'>('English · Svarah')
  const [objective, setObjective] = useState<'Mel loss' | 'Duration loss'>('Mel loss')
  const train = objective === 'Mel loss' ? [91,72,59,51,44,39,35,32,29,27,25,23,21,20,19,18,17] : [83,66,54,45,39,34,30,27,24,22,20,18,17,16,15,14,13]
  const validation = objective === 'Mel loss' ? [97,80,67,61,54,51,47,45,43,42,40,39,38,38,37,37,36] : [92,75,63,55,49,45,41,38,36,34,33,32,31,31,30,30,29]
  const coords = (values: number[]) => values.map((v,i) => `${45 + i*39},${190-v*1.55}`).join(' ')
  return <div className="research-view"><div className="view-intro"><div><span className="list-overline">EXPERIMENT DASHBOARD · 02</span><h2>Results & metrics</h2><p>Track optimization behavior and compare train versus held-out validation loss.</p></div><span className="data-badge"><span/> No experiment logs attached</span></div><div className="view-toolbar"><div className="mini-tabs">{(['English · Svarah','Telugu · IndicTTS'] as const).map(item=><button className={lang === item ? 'mini-tab active' : 'mini-tab'} onClick={() => setLang(item)} key={item}>{item}</button>)}</div><div className="mini-tabs">{(['Mel loss','Duration loss'] as const).map(item=><button className={objective === item ? 'mini-tab active' : 'mini-tab'} onClick={() => setObjective(item)} key={item}>{item}</button>)}</div></div><div className="metric-cards"><div className="metric-card"><span>DATASET</span><b>{lang.startsWith('English') ? 'Svarah' : 'IndicTTS'}</b><small>{lang.startsWith('English') ? 'English · independent run' : 'Telugu · independent run'}</small></div><div className="metric-card"><span>TRAINING SPLIT TARGET</span><b>5 <small>hours</small></b><small>Speaker-disjoint selection</small></div><div className="metric-card"><span>VALIDATION SPLIT TARGET</span><b>1 <small>hour</small></b><small>Held out · no overlap</small></div><div className="metric-card"><span>RUN STATUS</span><b className="pending-metric">Not reported</b><small>Awaiting loss logs</small></div></div><section className="chart-card loss-card"><div className="chart-head"><div><span className="list-overline">{lang.toUpperCase()} · TRAINING HISTORY</span><h3>{objective} across epochs</h3></div><span className="chart-unit">Loss · illustrative</span></div><svg className="research-chart loss-chart" viewBox="0 0 720 235" role="img" aria-label="Illustrative training and validation loss curves"><defs><linearGradient id="lossFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#34cbe3" stopOpacity=".13"/><stop offset="1" stopColor="#34cbe3" stopOpacity="0"/></linearGradient></defs>{[35,75,115,155,195].map(y=><g key={y}><line x1="45" x2="690" y1={y} y2={y} className="chart-gridline"/><text x="8" y={y+3} className="chart-tick">{((215-y)/180).toFixed(2)}</text></g>)}<polygon points={`45,195 ${coords(train)} 669,195`} fill="url(#lossFill)"/><polyline points={coords(train)} fill="none" stroke="#687bff" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round"/><polyline points={coords(validation)} fill="none" stroke="#52cee3" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="7 5"/>{[0,4,8,12,16].map((v,i)=><text key={v} x={45+i*156} y="220" className="chart-tick">Epoch {v+1}</text>)}</svg><div className="chart-foot"><span><i className="legend-line indigo-line"/>Training loss</span><span><i className="legend-line cyan-line"/>Validation loss</span><span className="illustrative-tag">Illustrative only · not run data</span></div></section><div className="preview-disclaimer"><CircleHelp size={15}/> Attachments contain deployment URLs only, not training logs or measured metrics. Curves above demonstrate the viewer layout and must not be cited as results.</div></div>
}

function Preparation() {
  return <div className="prep-page" id="preparation"><div className="prep-intro"><div className="prep-badge"><Settings2 size={16}/> ASSIGNMENT OVERVIEW</div><h2>FastSpeech 2 · English & Telugu</h2><p>Two independent text-to-speech tracks: English using Svarah, and Telugu using IndicTTS. Train and validate each language separately, retaining speaker-disjoint splits.</p></div><div className="source-warning"><span className="warning-mark">!</span><div><b>Attached artifact check</b><p>Both supplied files contain FastSpeech 2 deployment URLs only. No dataset archives, generated utterances, model checkpoints, training logs, or validation outputs were included, so real audio and metric traces cannot be shown here.</p><div className="source-links"><a href="https://fastspeech2-research-lab-7tj0.arcada.app" target="_blank" rel="noreferrer">English model deployment <ExternalLink size={13}/></a><a href="https://fastspeech2-research-lab-7ig0.arcada.app" target="_blank" rel="noreferrer">Telugu model deployment <ExternalLink size={13}/></a></div></div></div><div className="split-title"><div><span className="list-overline">DATASET & SPLIT PLAN</span><h2>Separate training and validation</h2></div><span className="split-total">6 hours per language</span></div><div className="split-grid">{[['EN','English · Svarah','en-US'],['తె','Telugu · IndicTTS','te-IN']].map(([symbol,name,locale])=><div className="split-card" key={name}><div className="split-card-heading"><span className={`split-lang ${name.startsWith('Telugu') ? 'te-flag' : ''}`}>{symbol}</span><div><b>{name}</b><small>{locale} · independent model</small></div><span className="split-ok"><Check size={14}/> Separate</span></div><div className="split-row"><span><i className="legend-train"/> Training</span><b>5 hours</b><div className="split-bar"><i/></div><small>Duration-based subsampling, stratified by speaker and session.</small></div><div className="split-row validation"><span><i className="legend-valid"/> Validation</span><b>1 hour</b><div className="split-bar"><i/></div><small>Hold out complete speakers/sessions; zero clip overlap.</small></div></div>)}</div><div className="method-grid"><div className="method-card"><span className="method-number">01</span><h3>Selection & subsampling</h3><p>Filter to consented, clean recordings in the target language. Split by speaker/session before subsampling. Select the 5-hour train and 1-hour validation targets by cumulative duration—not clip count—and stratify by speaker, phonetic coverage, and recording conditions.</p></div><div className="method-card"><span className="method-number">02</span><h3>Language-aware preprocessing</h3><p>Preserve original transcripts plus normalized training forms. English: normalize Unicode, standardize numeric expansion, retain lexical stress. Telugu: preserve script and vowel marks, normalize Unicode to NFC, review token spacing, and avoid transliteration. Keep benchmark prompts verbatim.</p></div><div className="method-card"><span className="method-number">03</span><h3>Audio fidelity & audit</h3><p>Use clean mono PCM WAV at the model’s native sample rate. Check clipping, noise, silence and transcript alignment; apply consistent loudness normalization without aggressive denoising. Audit duration totals, speaker IDs and split checksums.</p></div><div className="method-card"><span className="method-number">04</span><h3>Independent evaluation</h3><p>Train English and Telugu separately with language-matched text processing and speaker inventories. Log per-epoch training/validation losses, checkpoints, random seeds and preprocessing versions; evaluate only on the held-out validation sets.</p></div></div></div>
}

export default App
